<?php require_once('Connections/conn.php'); ?>
<?php
$currentPage = $_SERVER["PHP_SELF"];

$maxRows_links = 5;
$pageNum_links = 0;
if (isset($_GET['pageNum_links'])) {
  $pageNum_links = $_GET['pageNum_links'];
}
$startRow_links = $pageNum_links * $maxRows_links;

mysql_select_db($database_conn, $conn);
$query_links = "SELECT description, address FROM links ORDER BY description ASC";
$query_limit_links = sprintf("%s LIMIT %d, %d", $query_links, $startRow_links, $maxRows_links);
$links = mysql_query($query_limit_links, $conn) or die(mysql_error());
$row_links = mysql_fetch_assoc($links);

if (isset($_GET['totalRows_links'])) {
  $totalRows_links = $_GET['totalRows_links'];
} else {
  $all_links = mysql_query($query_links);
  $totalRows_links = mysql_num_rows($all_links);
}
$totalPages_links = ceil($totalRows_links/$maxRows_links)-1;

$queryString_links = "";
if (!empty($_SERVER['QUERY_STRING'])) {
  $params = explode("&", $_SERVER['QUERY_STRING']);
  $newParams = array();
  foreach ($params as $param) {
    if (stristr($param, "pageNum_links") == false && 
        stristr($param, "totalRows_links") == false) {
      array_push($newParams, $param);
    }
  }
  if (count($newParams) != 0) {
    $queryString_links = "&" . htmlentities(implode("&", $newParams));
  }
}
$queryString_links = sprintf("&totalRows_links=%d%s", $totalRows_links, $queryString_links);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
        "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<head>
<meta http-equiv="content-type" content="text/html; charset=iso-8859-1" />
<title>basic xhtml/css layout | php version</title>
<!-- this link method is fine for pretty much all CSS-friendly browsers  -->
<link rel="stylesheet" type="text/css" href="css/green.css" title="green" /> 
<link rel="alternate stylesheet" type="text/css" media="all" href="css/purple.css" title="purple" /> 
<link rel="alternate stylesheet" type="text/css" media="all" href="css/large.css" title="large" /> 
<link rel="alternate stylesheet" type="text/css" media="all" href="css/reverse.css" title="reverse" /> 
<!-- the @import method only works from 5.0 and upwards  -->
<!-- so, using @import would "hide" the more sophisticated sheet from < 5.0 browsers -->
<!-- <style type="text/css" media="all">@import "fancy_style.css";</style> -->
<!-- keeping all your big javascripts in separate tidy files makes things easier on bandwidth -->
<script language="JavaScript" type="text/javascript" src="js/styleswitcher.js"></script> 
</head>
<!-- you can have a default Status Bar message like this -->
<body onLoad="window.defaultStatus='friends of ED | Mac OS X Web Development Fundamentals: Chapter 3'">
<div id="container">
<div id="banner"><h1>this is the #banner &lt;div&gt;</h1></div>
<div id="sidebar">
<div id="navcontainer">
<ul id="navlist">
<li><a href="index.php" title="Back to the Home Page">About Me</a></li>
<li><a href="projects.php" title="Projects, past & present">Projects</a></li>
<li><a href="contact.php" title="Contact me">Contact</a></li>
<li id="active"><a href="#" title="Explore other sites">Links</a></li>
<li><a href="forum/index.php" title="leave a message on the forum">Forum</a></li>
</ul>
</div>
<div id="styletool">
<a href="#" title="Switch Styles: green" onClick="setActiveStyleSheet('green'); return false;" accesskey="g"><img src="images/selector_green.gif" alt="Switch Styles: green" /></a> 
<a href="#" title="Switch Styles: purple" onClick="setActiveStyleSheet('purple'); return false;" accesskey="p"><img src="images/selector_purple.gif" alt="Switch Styles: purple" /></a> 
<a href="#" title="Switch Styles: large type" onClick="setActiveStyleSheet('large'); return false;" accesskey="l"><img src="images/selector_large.gif" alt="Switch Styles: large type" /></a> 
<a href="#" title="Switch Styles: reverse colors, large type" onClick="setActiveStyleSheet('reverse'); return false;" accesskey="r"><img src="images/selector_large_reverse.gif" alt="Switch Styles: reverse colors, large type" /></a> 
</div>
<div id="valid">
<a href="http://validator.w3.org/check/referer" title="Validated XHTML 1.0"><img src="images/xhtml10.png" alt="XHTML 1.0 valid" width="80" height="15" border="0" /></a><br />
<a href="http://jigsaw.w3.org/css-validator/check/referer" title="Validated CSS"><img src="images/css.gif" alt="CSS valid" width="80" height="15" border="0" /></a><br />
<a href="http://www.contentquality.com/mynewtester/cynthia.exe?Url1=http://www.freakindesign.com/booktest" title="Validated Section 508"><img src="images/sec508a.gif" alt="508 valid" width="80" height="15" border="0" /></a>
</div>
</div>
<div id="content">
<table border="0" cellpadding="2" cellspacing="2">
<tr>
<td>description</td>
<td>address</td>
</tr>
<?php do { ?>
<tr>
<td><?php echo $row_links['description']; ?></td>
<td><?php echo $row_links['address']; ?></td>
</tr>
<?php } while ($row_links = mysql_fetch_assoc($links)); ?>
</table>

<table border="0" width="50%" align="left">
<tr>
<td width="23%" align="center">
<?php if ($pageNum_links > 0) { // Show if not first page ?>
<a href="<?php printf("%s?pageNum_links=%d%s", $currentPage, 0, $queryString_links); ?>">First</a>
<?php } // Show if not first page ?>
</td>
<td width="31%" align="center">
<?php if ($pageNum_links > 0) { // Show if not first page ?>
<a href="<?php printf("%s?pageNum_links=%d%s", $currentPage, max(0, $pageNum_links - 1), $queryString_links); ?>">Previous</a>
<?php } // Show if not first page ?>
</td>
<td width="23%" align="center">
<?php if ($pageNum_links < $totalPages_links) { // Show if not last page ?>
<a href="<?php printf("%s?pageNum_links=%d%s", $currentPage, min($totalPages_links, $pageNum_links + 1), $queryString_links); ?>">Next</a>
<?php } // Show if not last page ?>
</td>
<td width="23%" align="center">
<?php if ($pageNum_links < $totalPages_links) { // Show if not last page ?>
<a href="<?php printf("%s?pageNum_links=%d%s", $currentPage, $totalPages_links, $queryString_links); ?>">Last</a>
<?php } // Show if not last page ?>
</td>
</tr>
</table>
</div>
<div id="footer">this is the #footer &lt;div&gt;<br />everything &copy;2003 freakindesign</div>
</div>
</body>
</html>
<?php
mysql_free_result($links);
?>
