INSERT INTO links (id, description, address) VALUES (NULL, "Apple\'s Website", "http://www.apple.com/");
INSERT INTO links (id, description, address) VALUES (NULL, "friends of ED", "http://www.friendsofed.com/");
INSERT INTO links (id, description, address) VALUES (NULL, "Macromedia", "http://www.macromedia.com/");
INSERT INTO links (id, description, address) VALUES (NULL, "Adobe", "http://www.adobe.com/");
INSERT INTO links (id, description, address) VALUES (NULL, "Mac OS X Hints", "http://www.macosxhints.com/");
INSERT INTO links (id, description, address) VALUES (NULL, "MacNN", "http://www.macnn.com/");
INSERT INTO links (id, description, address) VALUES (NULL, "Speak\'n\'Spell", "http://www.speaknspell.co.uk/");