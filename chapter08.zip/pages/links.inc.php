<h2>links:</h2>
<table width="100%" border=0 cellpadding=2 cellspacing=2>
<tr>
<td valign=top>
<b>LUNARCLICK: OFFICIAL</b></td>
<td valign=top>
<b>LUNARCLICK: FAN</b></td>
</tr>
<tr>
<td valign=top>
<ul>
<li><a href="http://www.lunarclick.org" target=click>lunarclick.ORG</a>
<li><a href="http://www.lunarclick.net" target=click>lunarclick.NET</a>
<li><a href="http://www.lunarclick.com/mp3" target=click>lunarclick.com/MP3</a>
</ul>
</td>
<td valign=top>
<ul>
<li><a href="http://www.broken-promises.com/" target=click>www.broken-promises.com</a>
<li><a href="http://www.sparklelips.com/" target="click">www.sparklelips.com</a>
<li><a href="http://www.rayshele.com/" target="click">www.rayshele.com</a>
</ul>
<p>got a fan site?  submit it <a href="http://www.lunarclick.com/index.php?id=submit">here</a>!</p>
</td>
</tr>
<tr>
<td valign=top>
<b>BANDS</b></td>
<td valign=top>
<b>OTHERS</b></td>
</tr>
<tr>
<td valign=top>
<ul>
<li><a href="http://www.electroshot.com/aphex" target=click>kant</a>
<li><a href="http://www.nin.com" title="Nine Inch Nails" target=click>nine inch nails</a>
<li><a href="http://www.deadsy.com/" target=click>nomeansno</a>
<li><a href="http://www.electroshot.com/aphex" target=click>therapy?</a>
<li><a href="http://www.nin.com" title="Nine Inch Nails" target=click>intentions of an asteroid</a>
</ul>
</td>
<td valign=top>
<ul>
<li><a href="http://www.barsinister.net/" target=click>omgwtfbbq</a>
<li><a href="http://www.houseofninja.com/" target=click>house of ninja</a>
<li><a href="http://www.seventh-circle.com/" target=click>suicide girls</a>
<li><a href="http://www.electroshot.com/aphex" target=click>system error</a>
<li><a href="http://www.nin.com" title="Nine Inch Nails" target=click>friends of ED</a>
</ul>
</td>
</tr>
</table>