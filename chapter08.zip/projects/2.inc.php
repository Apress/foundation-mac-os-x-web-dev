<p>Projects page #2</p>
<br />
<a href="projects.php?id=1" title="Previous Page">Previous</a> | 
<a href="projects.php?id=3" title="Next Page">Next</a>