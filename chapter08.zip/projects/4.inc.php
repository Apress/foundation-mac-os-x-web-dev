<p>Projects page #4</p>
<br />
<a href="projects.php?id=3" title="Previous Page">Previous</a> | 
Next