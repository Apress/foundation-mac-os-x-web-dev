<div id="contentLeft">
<img src="images/FoED.gif" width="200" height="69" title="friends of ED logo" alt="friends of ED logo" />
<p>I first started working for <a href="http://www.friendsofed.com/" title="visit the friends of ED web site">friends of ED</a> in the summer of 2001.  In my initial capacity of Technical Reviewer, I worked on their 
<a href="http://www.friendsofed.com/books/1903450403/index.html" title="Foundation ColdFusion for Flash">Foundation ColdFusion for Flash</a> book. I'd never used ColdFusion before, so this was a nice challenge.</p>
<p>A later project saw me working on some more Flash-based work, before working as Technical Reviewer on their 
<a href="http://www.friendsofed.com/books/1590590976/index.html" title="Foundation Dreamweaver MX">Foundation Dreamweaver MX</a> book.</p>
<p>I have just finished writing Foundation Mac OS X Web Development, which is possibly the biggest project I've undertaken, to date. </p>
<p>friends of ED are a great company to work for, and writing this book has been a fantastic (yet completely daunting) experience for me.</p>
<br />
Previous | 
<a href="projects.php?id=2" title="Next Page">Next</a>
</div>
<div id="contentRight">
<img src="images/books.jpg" width="250" height="500" alt="friends of ED books" title="friends of ED books" />
</div>