<p>Projects page #3</p>
<br />
<a href="projects.php?id=2" title="Previous Page">Previous</a> | 
<a href="projects.php?id=4" title="Next Page">Next</a>