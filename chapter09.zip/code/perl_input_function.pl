#!/usr/bin/perl
sub htmlEscape {
       $userInput = @_[0];
       $userInput =~ s/>/&gt;/g;
       $userInput =~ s/</&lt;/g;
       return($userInput);
}
print &htmlEscape("<b>hello</b>\n");
