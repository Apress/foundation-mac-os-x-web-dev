<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
        "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<head>
	<meta http-equiv="content-type" content="text/html; charset=iso-8859-1" />
	<title>Image Gallery</title>
</head>
<body>
<?
$directoryName = "pictures";
$address = "http://localhost/imagegallery";
$url = "$address/$directoryName/";
$directory = getcwd() . "/" . $directoryName . "/";
if(is_dir($directory)) {
$dHandle = opendir($directory) or die("Unable to open directory!");
while($file = readdir($dHandle)) {
    if(eregi("\.jpg$", $file)) {
        echo '<img src="'. $url . $file . '"><br>';
        echo eregi_replace("\.jpg$", "", ucwords(strtolower($file))) . "<p>";
    }
}
closedir($dHandle);
} else {
die("Unable to open directory!");
}
?>
</body>
</html>
