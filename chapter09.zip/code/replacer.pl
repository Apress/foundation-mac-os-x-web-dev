#!/usr/bin/perl
$directory = $ARGV[0];
$find = $ARGV[1];
$replace = $ARGV[2];

opendir(DIRECTORYHANDLE, $directory) || die("Unable to open directory $directory");

while($file = readdir(DIRECTORYHANDLE)) {
    next if $file !~ /\.txt$/;
    @textlines = ();
    open(FILE, "$directory/$file") || die ("Unable to open file!");
    while(<FILE>) {
           $replacedText = $_;
           $replacedText =~ s/$find/$replace/g;
           push(@textlines, $replacedText);
    }
    close(FILE);

    open(OUTFILE, ">$directory/$file") || die ("Unable to open file for writing!");
    foreach $line(@textlines) {
        print OUTFILE $line;
    }
    close(OUTFILE);
 }