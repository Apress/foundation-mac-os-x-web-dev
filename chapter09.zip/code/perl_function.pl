#!/usr/bin/perl
sub perlFunction {
        return(@_);
}
print &perlFunction("Hello from a perl function\n");