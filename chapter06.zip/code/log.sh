#!/bin/sh

cd /private/var/log/httpd    # change to the directory
today=`date +"%Y%m%d"`  # get today's date in YYYYmmdd format

mv access_log access.${today} # append today's date to the access log filename
tail -n 30 access.${today} > access_log  # grab the last 30 lines and cat it to the end of the new access log
gzip -9 access.${today}  # gzip today's access log
mv access.${today}.gz /Users/phil/Desktop/access.${today}.gz # move the new file to the desktop

mv error_log error.${today} # append today's date to the error log filename
tail -n 30 error.${today} > error_log  # grab the last 30 lines and cat it to the end of the new error log
gzip -9 error.${today}  # gzip today's error log
mv error.${today}.gz /Users/phil/Desktop/error.${today}.gz # move the new file to the desktop